package SAE501.JLTT.TrainU.Service;

import com.stripe.model.PaymentIntent;

import java.util.Map;

public interface StripePort {
    String createPaymentIntent(int amountCent, String currency, String email,
                               Map<String,String> metadata, String idemKey);
    void cancelPaymentIntent(String paymentIntentId);
    String createRefundByPaymentIntent(String paymentIntentId, Integer amountCent,
                                       Map<String,String> metadata);

    // NEW: lire l’état réel chez Stripe
    PaymentIntent retrievePaymentIntent(String paymentIntentId);
}