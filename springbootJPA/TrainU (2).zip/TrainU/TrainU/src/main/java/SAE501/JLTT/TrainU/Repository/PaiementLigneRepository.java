package SAE501.JLTT.TrainU.Repository;

import SAE501.JLTT.TrainU.Model.PaiementLigne;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaiementLigneRepository extends JpaRepository<PaiementLigne, Long> { }
